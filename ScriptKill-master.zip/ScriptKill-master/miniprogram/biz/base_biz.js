/**
 * Notes: 基础模块业务逻辑
 * Ver : CCMiniCloud Framework 2.0.1 ALL RIGHTS RESERVED BY cclinux@qq.com
 * Date: 2020-11-14 07:48:00 
 */
const dataHelper = require('../helper/data_helper.js');

class BaseBiz {
	 
}

module.exports = BaseBiz;